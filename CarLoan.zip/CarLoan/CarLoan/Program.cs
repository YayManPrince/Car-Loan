﻿using System;

namespace CarLoan
{
    class Loan
    {
        public static void Main(String[] args)
        {
            int carLoan = 10000;
            int loanLength = 3;
            int interestRate = 5;
            int downPayment = 2000;
            

            Console.WriteLine("Would you take out a Car loan or Pay in full?");
            Console.WriteLine("Press (y) for Car Loan or Any other key for Full Pay: ");
            String ans = Console.ReadLine();

            if (ans == "y")
            {
                Console.WriteLine("\nCar Loan, the minimum Down Payment is: $" + downPayment);
                Console.WriteLine("What is Customer down payment: ");
                int custDP = Convert.ToInt32(Console.ReadLine());

                if (custDP >= downPayment)
                {
                    Console.WriteLine("Valid Down Payment");
                    int remainingBalance = carLoan - custDP;
                    int months = loanLength * 12;
                    Console.WriteLine("Loan Length in months is: " + months + " months");
                    int monthlyBalance = remainingBalance / months;
                    int interest = (monthlyBalance * interestRate) / 100;
                    Console.WriteLine("Your loan interest is " + interest + " %");
                    int monthlyPayment = monthlyBalance + interest;

                    Console.WriteLine("\nYour Monthly Payment is $" + monthlyPayment);

                }else if (custDP < downPayment)
                {
                    Console.WriteLine("Invalid Down Payment");
                }

            }else
            {
                Console.WriteLine("Full Payment Required is: $" + carLoan);
                Console.WriteLine("\nPlease Enter amount: ");
                int fullPay = Convert.ToInt32(Console.ReadLine());

                if (fullPay >= carLoan)
                {
                    Console.WriteLine("Car can be paid in Full");
                }
                else
                {
                    Console.WriteLine("Invalid Payment, we suggest a Car Loan");
                }
            }
        }
    }
}

